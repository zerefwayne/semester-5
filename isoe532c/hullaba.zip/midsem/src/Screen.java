import javax.swing.*;

public class Screen {

    private JPanel panel1;
    private JTextArea textArea1;
    private JButton calculateComplexityButton;

    public void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
